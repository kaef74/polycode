import '../../css/Header.css';

import logo from '../../../public/storage/Images/logo_new.png';


import { Link } from '@inertiajs/react';

export default function Header ({ auth }) {
    return (

        <header className='header'>

            <div className='header__container'>
                <Link href="/">
                    <img src={logo} className='header__logo' alt="Логотип" />
                </Link>
                <ul className='header__navbar'>
                    <li className='navbar__item'>
                        <Link href="/" className='navbar__link'>
                           Главная
                        </Link>
                    </li>
                    <li className='navbar__item'>
                        <Link href={route('education')} className='navbar__link'>
                            Обучение
                        </Link>
                    </li>
                    <li className='navbar__item'>
                        <a href="#" className='navbar__link'>Таблица лидеров</a>
                    </li>
                    <li className='navbar__item'>
                        <a href="#" className='navbar__link'>Форум</a>
                    </li>
                    <li className='navbar__item'>
                        <Link href={route('compiler')} className='navbar__link'>Компилятор</Link>
                    </li>
                </ul>
                { auth.user ? (
                    <Link
                        className='button header__button'
                        href={route('profile')}

                    >
                        Профиль
                    </Link>
                ) : (
                    <>
                        <Link
                            href={route('auth')}
                            className='button header__button'
                        >
                            Вход / Регистрация
                        </Link>
                    </>
                )}
            </div>
        </header>
    );
}

